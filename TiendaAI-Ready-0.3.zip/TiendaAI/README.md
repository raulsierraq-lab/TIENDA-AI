# TIENDA AI — Android 0.3

App de caja / punto de venta funcional y más completa (offline-first).

## Funcionalidades

- Caja (POS) con carrito, cantidades, total y finalizar venta.
- Catálogo de productos persistente (Room).
- **Fotos de productos** (campo preparado; se puede extender con cámara fácilmente).
- Escáner de códigos de barras (CameraX + ML Kit).
- Historial de ventas con **detalle de ítems**.
- **Reportes** básicos (total de ventas e ingresos).
- **Exportar ventas a CSV** y compartir.
- Selector de moneda.
- **Modo oscuro** automático (sigue el sistema).
- Datos locales que no se pierden al cerrar la app.

## Aún no incluye (requieren servicios externos)

- Reconocimiento visual avanzado por IA (foto → identificación automática de producto).
- Sincronización en la nube / multi-dispositivo.
- Pagos reales, suscripciones o facturación electrónica.
- Multi-usuario con roles y autenticación.

Estas partes quedan preparadas en la arquitectura (entidades, pantallas, DAOs) para conectarlas cuando se añada un backend.

## Cómo usar

1. Abre el proyecto en Android Studio (JDK 17, SDK 35).
2. Sincroniza y ejecuta.
3. Concede permiso de cámara al usar el escáner.
4. Desde Historial puedes exportar CSV.
5. Usa el icono de reportes en la barra superior de la caja.

Package: `com.tiendaai.app`
