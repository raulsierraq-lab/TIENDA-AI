package com.tiendaai.app.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tiendaai.app.viewmodel.PosViewModel

object Routes {
    const val POS = "pos"
    const val CATALOG = "catalog"
    const val HISTORY = "history"
    const val SCANNER = "scanner"
    const val REPORTS = "reports"
}

@Composable
fun TiendaNavHost() {
    val navController = rememberNavController()
    val viewModel: PosViewModel = viewModel()

    NavHost(navController = navController, startDestination = Routes.POS) {
        composable(Routes.POS) {
            PosScreen(
                viewModel = viewModel,
                onNavigateToCatalog = { navController.navigate(Routes.CATALOG) },
                onNavigateToHistory = { navController.navigate(Routes.HISTORY) },
                onNavigateToScanner = { navController.navigate(Routes.SCANNER) },
                onNavigateToReports = { navController.navigate(Routes.REPORTS) }
            )
        }
        composable(Routes.CATALOG) {
            CatalogScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SCANNER) {
            ScannerScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onProductFound = { product ->
                    viewModel.addToCart(product)
                    navController.popBackStack()
                }
            )
        }
        composable(Routes.REPORTS) {
            ReportsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
