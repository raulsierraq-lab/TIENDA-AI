package com.tiendaai.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tiendaai.app.viewmodel.PosViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: PosViewModel,
    onBack: () -> Unit
) {
    val totalRevenue by viewModel.totalRevenue.collectAsState()
    val salesCount by viewModel.salesCount.collectAsState()
    val sales by viewModel.sales.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reportes") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("Resumen general", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("Ventas realizadas: $salesCount", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Ingresos totales: ${NumberFormat.getNumberInstance(Locale.getDefault()).format(totalRevenue)}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            item {
                Text("Últimas ventas", style = MaterialTheme.typography.titleMedium)
            }
            if (sales.isEmpty()) {
                item { Text("No hay ventas aún.") }
            } else {
                items(sales.take(10)) { sale ->
                    Card {
                        Column(Modifier.padding(12.dp)) {
                            Text("Venta #${sale.id} — ${sale.total} ${sale.currency}")
                            Text(
                                java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                                    .format(java.util.Date(sale.timestamp)),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
            item {
                Text(
                    "Nota: Reportes avanzados (por día, top productos, gráficos) y exportación completa se pueden ampliar fácilmente desde aquí.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
