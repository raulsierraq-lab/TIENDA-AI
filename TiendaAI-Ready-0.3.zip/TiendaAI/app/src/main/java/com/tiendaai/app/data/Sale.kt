package com.tiendaai.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val total: Long,
    val currency: String,
    val timestamp: Long = System.currentTimeMillis()
)
