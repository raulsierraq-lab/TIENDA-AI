package com.tiendaai.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val price: Long,
    val barcode: String? = null,
    val imagePath: String? = null, // ruta local de la foto del producto
    val createdAt: Long = System.currentTimeMillis()
)
