package com.tiendaai.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

data class SaleWithItems(
    val sale: Sale,
    val items: List<SaleItem>
)

@Dao
interface SaleDao {
    @Insert
    suspend fun insertSale(sale: Sale): Long

    @Insert
    suspend fun insertItems(items: List<SaleItem>)

    @Transaction
    suspend fun completeSale(sale: Sale, items: List<SaleItem>): Long {
        val saleId = insertSale(sale)
        val itemsWithId = items.map { it.copy(saleId = saleId) }
        insertItems(itemsWithId)
        return saleId
    }

    @Query("SELECT * FROM sales ORDER BY timestamp DESC")
    fun getAllSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    suspend fun getItemsForSale(saleId: Long): List<SaleItem>

    @Query("SELECT SUM(total) FROM sales")
    fun getTotalRevenue(): Flow<Long?>

    @Query("SELECT COUNT(*) FROM sales")
    fun getSalesCount(): Flow<Int>
}
