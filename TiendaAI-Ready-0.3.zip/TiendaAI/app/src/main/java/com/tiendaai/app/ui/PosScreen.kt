package com.tiendaai.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.tiendaai.app.viewmodel.PosViewModel
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    viewModel: PosViewModel,
    onNavigateToCatalog: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToScanner: () -> Unit,
    onNavigateToReports: () -> Unit
) {
    val cart by viewModel.cart.collectAsState()
    val products by viewModel.products.collectAsState()
    val total by viewModel.total.collectAsState()
    var currencyCode by remember { mutableStateOf("COP") }
    var showAddManual by remember { mutableStateOf(false) }
    var manualName by remember { mutableStateOf("") }
    var manualPrice by remember { mutableStateOf("") }

    val currencyOptions = listOf("COP", "USD", "MXN", "EUR", "BRL", "PEN", "CLP", "ARS", "GBP", "CAD")

    fun money(value: Long): String {
        val locale = when (currencyCode) {
            "EUR" -> Locale("es", "ES")
            "BRL" -> Locale("pt", "BR")
            "USD" -> Locale.US
            else -> Locale("es", "CO")
        }
        val formatter = NumberFormat.getCurrencyInstance(locale)
        formatter.currency = Currency.getInstance(currencyCode)
        formatter.maximumFractionDigits = if (currencyCode in listOf("COP", "CLP", "ARS")) 0 else 2
        return formatter.format(value)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("TIENDA AI", fontWeight = FontWeight.Bold)
                        Text("Caja inteligente", style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToScanner) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Escanear")
                    }
                    IconButton(onClick = onNavigateToCatalog) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Catálogo")
                    }
                    IconButton(onClick = onNavigateToHistory) {
                        Icon(Icons.Default.History, contentDescription = "Historial")
                    }
                    IconButton(onClick = onNavigateToReports) {
                        Icon(Icons.Default.Assessment, contentDescription = "Reportes")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddManual = true }) {
                Icon(Icons.Default.Add, contentDescription = "Agregar producto")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Currency selector
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Moneda", modifier = Modifier.weight(1f))
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }) { Text(currencyCode) }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        currencyOptions.forEach { code ->
                            DropdownMenuItem(
                                text = { Text(code) },
                                onClick = {
                                    currencyCode = code
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Text("Venta actual", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            if (cart.isEmpty()) {
                Text(
                    "Aún no hay productos en la venta. Escanea, elige del catálogo o agrega manualmente.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(cart) { index, item ->
                        Card {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.SemiBold)
                                    Text(money(item.price), style = MaterialTheme.typography.bodySmall)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { viewModel.updateQuantity(index, -1) }) {
                                        Text("-", style = MaterialTheme.typography.titleLarge)
                                    }
                                    Text("${item.quantity}", modifier = Modifier.padding(horizontal = 8.dp))
                                    IconButton(onClick = { viewModel.updateQuantity(index, 1) }) {
                                        Text("+", style = MaterialTheme.typography.titleLarge)
                                    }
                                }
                                Text(
                                    money(item.subtotal),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("TOTAL A COBRAR", style = MaterialTheme.typography.labelLarge)
                    Text(
                        money(total),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.completeSale(currencyCode) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = cart.isNotEmpty()
                    ) {
                        Text("Finalizar venta")
                    }
                    if (cart.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { viewModel.clearCart() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Limpiar caja")
                        }
                    }
                }
            }
        }
    }

    if (showAddManual) {
        AlertDialog(
            onDismissRequest = { showAddManual = false },
            title = { Text("Agregar producto manual") },
            text = {
                Column {
                    OutlinedTextField(
                        value = manualName,
                        onValueChange = { manualName = it },
                        label = { Text("Nombre") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = manualPrice,
                        onValueChange = { manualPrice = it.filter { c -> c.isDigit() } },
                        label = { Text("Precio") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val price = manualPrice.toLongOrNull()
                        if (manualName.isNotBlank() && price != null && price > 0) {
                            viewModel.addManual(manualName.trim(), price)
                            manualName = ""
                            manualPrice = ""
                            showAddManual = false
                        }
                    }
                ) { Text("Agregar") }
            },
            dismissButton = {
                TextButton(onClick = { showAddManual = false }) { Text("Cancelar") }
            }
        )
    }
}
