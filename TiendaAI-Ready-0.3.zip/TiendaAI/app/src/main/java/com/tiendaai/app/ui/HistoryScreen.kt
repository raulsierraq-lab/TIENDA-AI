package com.tiendaai.app.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.tiendaai.app.data.SaleItem
import com.tiendaai.app.viewmodel.PosViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: PosViewModel,
    onBack: () -> Unit
) {
    val sales by viewModel.sales.collectAsState()
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    var selectedSaleId by remember { mutableStateOf<Long?>(null) }
    var saleItems by remember { mutableStateOf<List<SaleItem>>(emptyList()) }

    LaunchedEffect(selectedSaleId) {
        selectedSaleId?.let { id ->
            saleItems = viewModel.getSaleItems(id)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Historial de ventas") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    TextButton(onClick = {
                        // Simple export
                        val csv = buildString {
                            append("ID,Fecha,Total,Moneda\n")
                            sales.forEach { s ->
                                append("${s.id},${dateFormat.format(Date(s.timestamp))},${s.total},${s.currency}\n")
                            }
                        }
                        val file = File(context.cacheDir, "ventas_tiendaai.csv")
                        file.writeText(csv)
                        val uri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            file
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/csv"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Exportar ventas"))
                    }) {
                        Text("Exportar CSV")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (sales.isEmpty()) {
                item { Text("Aún no hay ventas registradas.") }
            }
            items(sales) { sale ->
                Card(onClick = { selectedSaleId = sale.id }) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text("Venta #${sale.id}", fontWeight = FontWeight.Bold)
                        Text(dateFormat.format(Date(sale.timestamp)))
                        Text("Total: ${sale.total} ${sale.currency}", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    if (selectedSaleId != null) {
        AlertDialog(
            onDismissRequest = { selectedSaleId = null },
            title = { Text("Detalle de venta #${selectedSaleId}") },
            text = {
                Column {
                    if (saleItems.isEmpty()) {
                        Text("Cargando...")
                    } else {
                        saleItems.forEach { item ->
                            Text("${item.quantity}x ${item.name} — ${item.price * item.quantity}")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedSaleId = null }) { Text("Cerrar") }
            }
        )
    }
}
