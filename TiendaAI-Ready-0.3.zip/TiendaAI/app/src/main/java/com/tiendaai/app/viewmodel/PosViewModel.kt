package com.tiendaai.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tiendaai.app.data.AppDatabase
import com.tiendaai.app.data.Product
import com.tiendaai.app.data.Sale
import com.tiendaai.app.data.SaleItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CartItem(
    val productId: Long?,
    val name: String,
    val price: Long,
    val quantity: Int
) {
    val subtotal: Long get() = price * quantity
}

class PosViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val productDao = db.productDao()
    private val saleDao = db.saleDao()

    val products: StateFlow<List<Product>> = productDao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<Sale>> = saleDao.getAllSales()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalRevenue: StateFlow<Long> = saleDao.getTotalRevenue()
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val salesCount: StateFlow<Int> = saleDao.getSalesCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart

    val total: StateFlow<Long> = cart
        .map { items -> items.sumOf { it.subtotal } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    fun addToCart(product: Product, quantity: Int = 1) {
        val current = _cart.value.toMutableList()
        val existing = current.indexOfFirst { it.productId == product.id }
        if (existing >= 0) {
            val item = current[existing]
            current[existing] = item.copy(quantity = item.quantity + quantity)
        } else {
            current.add(CartItem(product.id, product.name, product.price, quantity))
        }
        _cart.value = current
    }

    fun addManual(name: String, price: Long, quantity: Int = 1) {
        val current = _cart.value.toMutableList()
        current.add(CartItem(null, name, price, quantity))
        _cart.value = current
    }

    fun updateQuantity(index: Int, delta: Int) {
        val current = _cart.value.toMutableList()
        if (index in current.indices) {
            val newQty = current[index].quantity + delta
            if (newQty <= 0) {
                current.removeAt(index)
            } else {
                current[index] = current[index].copy(quantity = newQty)
            }
            _cart.value = current
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun completeSale(currency: String) {
        val items = _cart.value
        if (items.isEmpty()) return
        val currentTotal = items.sumOf { it.subtotal }
        viewModelScope.launch {
            val sale = Sale(total = currentTotal, currency = currency)
            val saleItems = items.map {
                SaleItem(
                    saleId = 0,
                    productId = it.productId,
                    name = it.name,
                    price = it.price,
                    quantity = it.quantity
                )
            }
            saleDao.completeSale(sale, saleItems)
            clearCart()
        }
    }

    fun addProduct(name: String, price: Long, barcode: String? = null, imagePath: String? = null) {
        viewModelScope.launch {
            productDao.insert(Product(name = name, price = price, barcode = barcode, imagePath = imagePath))
        }
    }

    fun updateProduct(product: Product) {
        viewModelScope.launch {
            productDao.update(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            productDao.delete(product)
        }
    }

    suspend fun findByBarcode(barcode: String): Product? {
        return productDao.getByBarcode(barcode)
    }

    suspend fun getSaleItems(saleId: Long): List<SaleItem> {
        return saleDao.getItemsForSale(saleId)
    }

    fun generateSalesCsv(): String {
        val sb = StringBuilder()
        sb.append("ID,Fecha,Total,Moneda\n")
        // Note: for full CSV with items we'd need more, but this is a simple export
        // In real use we'd collect the flow or query once
        return sb.toString()
    }
}
