# TIENDA AI — Android starter 0.1

Starter Android nativo en Kotlin + Jetpack Compose.

## Incluye en esta primera base
- Pantalla inicial de caja.
- Selector inicial de moneda (COP, USD, MXN, EUR, BRL, PEN, CLP, ARS, GBP, CAD).
- Selector visual de idioma (la traducción completa se incorporará en la siguiente etapa).
- Alta manual de productos y precios.
- Suma automática de la venta actual.

## Todavía no incluye
- Persistencia Room (los datos se pierden al cerrar la app).
- Cámara / reconocimiento visual.
- Escáner de códigos de barras.
- Historial de ventas y sincronización.
- Suscripciones y pagos.

## Compilar
Abrir con Android Studio, usar JDK 17 y Android SDK 35, luego ejecutar la configuración Gradle.
Este repositorio es una base de desarrollo, no una versión lista para publicar.

## Identificador
`com.tiendaai.app`
