package com.tiendaai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale

data class Product(val name: String, val price: Long, val quantity: Int = 1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TiendaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TiendaApp() {
    var currencyCode by remember { mutableStateOf("COP") }
    var language by remember { mutableStateOf("Español") }
    var productName by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var products by remember { mutableStateOf(listOf<Product>()) }

    val total = products.sumOf { it.price * it.quantity }
    val currencyOptions = listOf("COP", "USD", "MXN", "EUR", "BRL", "PEN", "CLP", "ARS", "GBP", "CAD")
    val locale = when (currencyCode) {
        "EUR" -> Locale("es", "ES")
        "BRL" -> Locale("pt", "BR")
        "USD" -> Locale.US
        else -> Locale("es", "CO")
    }
    fun money(value: Long): String {
        val formatter = NumberFormat.getCurrencyInstance(locale)
        formatter.currency = Currency.getInstance(currencyCode)
        formatter.maximumFractionDigits = if (currencyCode in listOf("COP", "CLP", "ARS")) 0 else 2
        return formatter.format(value)
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("TIENDA AI", fontWeight = FontWeight.Bold)
                        Text("Caja inteligente", style = MaterialTheme.typography.labelSmall)
                    }
                })
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Configuración", style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Moneda", modifier = Modifier.weight(1f))
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }) { Text(currencyCode) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                currencyOptions.forEach { code ->
                                    DropdownMenuItem(text = { Text(code) }, onClick = {
                                        currencyCode = code
                                        expanded = false
                                    })
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Idioma", modifier = Modifier.weight(1f))
                        var langExpanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { langExpanded = true }) { Text(language) }
                            DropdownMenu(expanded = langExpanded, onDismissRequest = { langExpanded = false }) {
                                listOf("Español", "English", "Português").forEach { lang ->
                                    DropdownMenuItem(text = { Text(lang) }, onClick = {
                                        language = lang
                                        langExpanded = false
                                    })
                                }
                            }
                        }
                    }
                }
                item {
                    HorizontalDivider()
                    Text("Agregar producto", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = productName, onValueChange = { productName = it },
                        label = { Text("Nombre del producto") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = priceText, onValueChange = { priceText = it.filter { c -> c.isDigit() } },
                        label = { Text("Precio en $currencyCode") }, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    Button(
                        onClick = {
                            val price = priceText.toLongOrNull()
                            if (productName.isNotBlank() && price != null && price > 0) {
                                products = products + Product(productName.trim(), price)
                                productName = ""
                                priceText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = productName.isNotBlank() && (priceText.toLongOrNull() ?: 0) > 0
                    ) { Text("Añadir al catálogo y a la venta") }
                }
                item {
                    HorizontalDivider()
                    Text("Venta actual", style = MaterialTheme.typography.titleMedium)
                }
                if (products.isEmpty()) {
                    item { Text("Aún no hay productos. Agrega el primero para probar la caja.") }
                } else {
                    items(products) { product ->
                        Card {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(product.name, fontWeight = FontWeight.SemiBold)
                                    Text(money(product.price), style = MaterialTheme.typography.bodySmall)
                                }
                                Text(money(product.price), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("TOTAL A COBRAR", style = MaterialTheme.typography.labelLarge)
                            Text(money(total), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            OutlinedButton(
                                onClick = { products = emptyList() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = products.isNotEmpty()
                            ) { Text("Finalizar venta y limpiar caja") }
                        }
                    }
                    Text(
                        "Prototipo 0.1: los datos aún se mantienen solo mientras la aplicación está abierta. " +
                            "La persistencia, cámara y escáner se incorporarán en las siguientes etapas.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
